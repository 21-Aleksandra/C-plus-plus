
class Carray
{

char letters[10];

public:
    Carray();
   ~Carray();
   void change(int n,char m);
   void toCapital();
   void toSmall();
   void print;

};
