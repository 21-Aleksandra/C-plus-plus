/*******************************************

Aleksandra Dmitruka,ad22069

C15. No masīva A(2n) iegūt divus masīvus B(n) un C(n) šādā veidā: 
atrast masīvā A divus pēc vērtības vistuvākos skaitļus - mazāko ielikt masīvā B, bet lielāko - masīvā C. 
Darbu turpināt, līdz visi atlikušie elementi ir izņemti un masīvi B un C aizpildīti.


Programma izveidota: 09.11.2022
*******************************************/


void order (double arr[],int dsize){
 for(i=0;i<dsize;i++){
  for(m=i+1;m<dsize;m++){
    if(arr[i]>=arr[m])
			{
				double k=arr[i];
				arr[i]=arr[j];
				arr[j]=k;
			}
    }
  } 
}

void BigSmall(double arr[],int dsize, int size){
  double *B = new double [size]; 
  double *C = new double [size]; 
  

  for(i=0;i<dsize-1;i++){
    if (arr[i]>=arr[i+1]){
      
      B[size]=arr[i+1];
      C[size]=arr[i];
      size--;

    else{

      C[size]=arr[i+1];
      B[size]=arr[i];
      size--;

    } 
   }
  }
}



#include <iostream>
using namespace std;

int main() {

   int ok;
   do {

    int n;
    int twice;
    do{
    cout<<"Enter array lenght n(n>0), which will be multiplied by two (2n):"<<endl;
    cin>>n;

    if(n<=0) { 
        cout<<"Error!The lenght of the array must be at least one(n>0)"<<endl;}

    }while(n<=0);  //Nodrošina ieejas datu korektumu

    twice=n*2; // Iegūst korektu A masīva izmēru

    double *A = new double [twice]; 

    for (int i = 0; i < twice; i++){
            cout<<"Enter array's element"<<endl;
            cin>>A[i]; 
        }

    order(A,twice);
    BigSmall(A,twice,n);


    cout<<"A array elements are:"<<endl;
    for (int i=0;i<twice;i++) {
      cout<<A[i]<<' ';
    }

    cout<<"B array elements are:"<<endl;
    for (int i=n-1;i>=0;i--) {
      cout << B[i]<<' '; }
    
    cout<<"C array elements are:"<<endl;
    for (int i=n-1;i>=0;i--) {
      cout << C[i]<<' '; }


    delete [] A;
		delete [] B;
    delete [] C; 

    cout << endl << "Enter 0 to exit or 1 to continue" << endl;
    cin >> ok;

    } while (ok == 1); //lauj atkārtot visu programmu, ja lietotājs beigās ievadīs ciparu 1
}



 /********************************

 *
 *        Ievads       |                     Programmas vēlamā reakcija                    |                    Rezultāts C++
 * --------------------+-------------------------------------------------------------------+----------------------------------------------------------------
 *       2 3 4 5       |        "Devision is 5/6  | Multiplication is 8/15"                |                          +
 *      -10 3 6 7      |        "Devision is -35/9 | Multiplication is -20/7"              |                          +
 *      21 -6 2 4      |         "Devision is 7/-1 | Multiplication is 7/-4"               |                          +
 *     -3 -7 -4 -5     |        "Devision is 15/28 | Multiplication is 12/35"              |                          +
 *      -4 0 2 7       |              Kļūda.Nedrīkst dalīt ar nulli                        | izdod paziņojumu "Error!The denominator of any fraction cannot be zero."
 * 2 1234567 3 12345678| "Devision is 8230452\1234567| Multiplication is 1\2540261108571"  |                          +

 *******************************/

